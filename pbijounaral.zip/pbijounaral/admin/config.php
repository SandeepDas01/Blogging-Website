<?php
	
	// Database host
	define("DB_HOST", "localhost");
	// Database user
	define("DB_USER", "root");
	// Database password
	define("DB_PASSWORD", "");
	// Database name
	define("DB_NAME", "pbijounaral");
 	//website URL
	define("BASEURL", "http://localhost/pbijounaral/admin/");
	define("BASEURLFORADMIN", "http://localhost/pbijounaral/");
	define("BASEURLFORSITE", "http://localhost/pbijounaral/");
 	//Website Name
	define("SITENAME", "Pharma and Biomedical Insight");
 	//Email address to send mail
	define("SENDMAILFROM", "info@jbkitchenfood.com");
	
?>

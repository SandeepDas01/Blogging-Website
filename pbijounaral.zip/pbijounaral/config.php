
<?php
		// Database host
	 define("DB_HOST", "localhost");
	// Database user
	define("DB_USER", "root");
	// Database password
	define("DB_PASSWORD","");
	// Database name
	define("DB_NAME", "pbijounaral");
	
	 
	//website URL
	define("BASEURL", "http://localhost/pbijounaral/");
	define("BASEURLFORIMAGES", "http://localhost/pbijounaral/admin/");

 
	//Website Name
	define("SITENAME", "http://localhost/pbijounaral/");
 	define("SENDMAILFROM", "info@pbijounaral.com");
	
	//Email address to send mail
	 
					 
 
?>

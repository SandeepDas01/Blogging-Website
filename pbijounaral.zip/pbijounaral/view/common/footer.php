	<!-- ============================ Call To Action ================================== -->
			<section class="theme-bg call-to-act-wrap">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							
							<div class="call-to-act">
								<div class="call-to-act-head">
									<h3>ABOUT JOURNAL</h3>
									<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Nulla posuere sollicitudin aliquam ultrices sagittis orci a. Pellentesque habitant morbi tristique senectus et netus et malesuada. Mi in nulla posuere sollicitudin aliquam ultrices. Vulputate ut pharetra sit amet aliquam id diam. Pharetra et ultrices neque ornare aenean. Urna neque viverra justo nec ultrices. Morbi tincidunt augue interdum velit. Viverra adipiscing at in tellus integer feugiat scelerisque. Elit scelerisque mauris pellentesque pulvinar pellentesque habitant morbi tristique senectus.
									Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Nulla posuere sollicitudin aliquam ultrices sagittis orci a. Pellentesque habitant morbi tristique senectus et netus et malesuada. Mi in nulla posuere sollicitudin aliquam ultrices. Vulputate ut pharetra sit amet aliquam id diam. Pharetra et ultrices neque ornare aenean. Urna neque viverra justo nec ultrices. Morbi tincidunt augue interdum velit. Viverra adipiscing at in tellus integer feugiat scelerisque. Elit scelerisque mauris pellentesque pulvinar pellentesque habitant morbi tristique senectus.</span>
								    <a href="About"> Red More<span class="ti-angle-double-right"></span></a>
								</div>
							
							</div>
							
						</div>
					</div>
				</div>
			</section>
			<!-- ============================ Call To Action End ================================== -->
			
			
			
			<!-- ============================ Footer Start ================================== -->
			<footer class="dark-footer skin-dark-footer">
				<div>
					<div class="container">
						<div class="row">
							
							<div class="col-lg-3 col-md-3">
								<div class="footer-widget">
									<img src="<?php echo BASEURL; ?>assets/img/logo-white.png" class="img-footer" alt="" />
									<div class="footer-add">
										<p>Collins Street West, Victoria,</br> Australia (AU4578).</p>
										<p><strong>Email:</strong></br>info@pbijournal.com</p>
										<p><strong>Call:</strong></br>+91 7014790412</p>
									</div>
									
								</div>
							</div>		
							<div class="col-lg-2 col-md-2">
								<div class="footer-widget">
									<h4 class="widget-title">About PBI Journal</h4>
									<ul class="footer-menu">
										<li><a href="Privacy-Policy">Privacy Policy</a></li>
										<li><a href="Termsof-Use">Terms of Use</a></li>
										<li><a href="#">Cookies</a></li>
										<li><a href="#">Accessibility</a></li>
										
									</ul>
								</div>
							</div>
									
							<div class="col-lg-2 col-md-2">
								<div class="footer-widget">
									<h4 class="widget-title">Opportunities</h4>
									<ul class="footer-menu">
										<li><a href="#">Subscription Agents</a></li>
										<li><a href="#">Advertisers & Corporate Partners</a></li>
										
									</ul>
								</div>
							</div>
							
							<div class="col-lg-2 col-md-2">
								<div class="footer-widget">
									<h4 class="widget-title">Connect with </h4>
									<ul class="footer-menu">
										<li><a href="Contact-Us">Get In Touch</a></li>
										
									</ul>
								</div>
							</div>
							
							<div class="col-lg-3 col-md-3">
								<div class="footer-widget">
									<h4 class="widget-title">Number of Visitor</h4>
									
									<a href="#" class="other-store-link">
										<div class="other-store-app">
											
                                        <!-- Start of WebFreeCounter Code -->
											<center><img src="https://www.webfreecounter.com/hit.php?id=gvnoqcd&nd=6&style=10" border="0" alt="web counter"></center>
									<!-- End of WebFreeCounter Code -->
										</div>
									</a>
								</div>
							</div>
							
						</div>
					</div>
				</div>
				
				<div class="footer-bottom">
					<div class="container">
						<div class="row align-items-center">
							
							<div class="col-lg-6 col-md-6">
								<p class="mb-0">© 2021 PBI Journal. Developed and Designd By <a href="">DOCTOMARK</a> All Rights Reserved</p>
							</div>
							
							<div class="col-lg-6 col-md-6 text-right">
								<ul class="footer-bottom-social">
									<li><a href="#"><i class="ti-facebook"></i></a></li>
									<li><a href="#"><i class="ti-twitter"></i></a></li>
									<li><a href="#"><i class="ti-instagram"></i></a></li>
									<li><a href="#"><i class="ti-linkedin"></i></a></li>
								</ul>
							</div>
							
						</div>
					</div>
				</div>
			</footer>
			<!-- ============================ Footer End ================================== -->
			
			
		
			<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
			<!-- Scripts
			================================================== -->
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/jquery.min.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/viewportchecker.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/bootstrap.min.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/bootsnav.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/select2.min.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/wysihtml5-0.3.0.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/bootstrap-wysihtml5.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/datedropper.min.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/dropzone.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/loader.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/owl.carousel.min.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/slick.min.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/gmap3.min.js"></script>
			<script type="text/javascript" src="<?php echo BASEURL; ?>assets/plugins/js/jquery.easy-autocomplete.min.js"></script>
			<!-- Custom Js -->
			<script src="<?php echo BASEURL; ?>assets/js/custom.js"></script><script type="text/javascript" src="assets/plugins/js/counterup.min.js"></script>
			<script src="<?php echo BASEURL; ?>assets/js/jQuery.style.switcher.js"></script>
			<script type="text/javascript">
				$(document).ready(function() {
					$('#styleOptions').styleSwitcher();
				});
			</script>
			<script>
				function openRightMenu() {
					document.getElementById("rightMenu").style.display = "block";
				}

				function closeRightMenu() {
					document.getElementById("rightMenu").style.display = "none";
				}
			</script>
			
		</div>
	</body>

</html>
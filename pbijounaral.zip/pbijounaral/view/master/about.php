<!-- Title Header Start -->
			<section class="inner-header-title no-br advance-header-title light-tx" style="background-image:url(assets/img/banner-10.jpg);">
				<div class="container">
					<h2><span>Pharma</span>  and Biomedical Insight</h2>
					
				</div>
			</section>
			
			<div class="clearfix"></div>
			<!-- Title Header End -->
			
			
		
			
			<!-- ========== Begin: Brows job Category ===============  -->
			<section class="full-detail-description full-detail">
				<div class="container">
					<div class="col-md-9 col-sm-12">
						
						
						<div class="row-bottom">
								
						</div>
						
						
						<!-- Ad banner -->
						<div class="row">
							
						<div class="row-bottom">
								<h2 class="detail-title">Abstracting and Indexing Information</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
						</div>
  
						
						<div class="row-bottom">
								<h2 class="detail-title">Abstracting and Indexing Information</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
						
						</div>
						
						
						<div class="row-bottom">
								<h2 class="detail-title">Claims</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
						
						</div>
						
						<div class="row-bottom">
								<h2 class="detail-title">Change of Postal Address</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
						
						</div>
						
						
						<div class="row-bottom">
								<h2 class="detail-title">Disclaimer</h2>
								<p>Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing Elit, Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam, Quis Nostrud Exercitation Ullamco Laboris Nisi Ut Aliquip Ex Ea Commodo Consequat. Duis Aute Irure Dolor In Reprehenderit In Voluptate Velit Esse Cillum Dolore Eu Fugiat Nulla Pariatur. Excepteur Sint Occaecat Cupidatat Non Proident, Sunt In Culpa Qui Officia Deserunt Mollit Anim Id Est Laborum.

Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing Elit, Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam, Quis Nostrud Exercitation Ullamco Laboris Nisi Ut Aliquip Ex Ea Commodo Consequat. Duis Aute Irure Dolor In Reprehenderit In Voluptate Velit Esse Cillum Dolore Eu Fugiat Nulla Pariatur. Excepteur Sint Occaecat Cupidatat Non Proident, Sunt In Culpa Qui Officia Deserunt Mollit Anim Id Est Laborum.</p>
						
						</div>
							
						</div>
					</div>
					
					<!-- Sidebar Start -->
					<div class="col-md-3 col-sm-12">
						<div class="sidebar right-sidebar">
						
							<div class="side-widget">
								
								
							</div>
							<div class="side-widget">
								
								<div class="job-alert">
									<div class="widget-text">
										
									<form action="#">
									<div class="search-form">
										<div class="input-group">
											<input type="text" class="form-control" placeholder="Search…">
											<span class="input-group-btn">
												<button type="button" class="btn btn-default">Go</button>
											</span>
										</div>
									</div>
								</form>
									</div>
								</div>
							</div>
							
							<div class="side-widget">
								
								<div class="widget-text padd-0">
									<div class="ad-banner">
										<img src="http://via.placeholder.com/320x285" class="img-responsive" alt="">
									</div>
								</div>
							</div>
							
							<div class="side-widget">
								
								<div class="widget-text padd-0">
									<div class="ad-banner">
										<img src="http://via.placeholder.com/320x285" class="img-responsive" alt="">
									</div>
								</div>
							</div>
							
							<div class="side-widget">
								<h2 class="side-widget-title">QUICK LINKS</h2>
								<div class="widget-text padd-0">
									 <ul class="footer-menu">
										<li><a href="home-6.html"><i class="fa fa-map-marker fa-2x"></i>&nbsp;&nbsp; Demo</a></li>
										<li><a href="browse-candidate-list.html"><i class="fa fa-users fa-2x"></i>&nbsp;&nbsp; Demo</a></li>
										<li><a href="browse-employer-list.html"><i class="fa fa-file-word-o fa-2x"></i>&nbsp;&nbsp; Demo</a></li>
										<li><a href="advance-search-2.html"><i class="fa fa-files-o fa-2x"></i>&nbsp;&nbsp; Demo</a></li>
										<li><a href="checkout.html"><i class="fa fa-rupee fa-2x"></i>&nbsp;&nbsp; Demo</a></li>
										<li><a href="checkout.html"><i class="fa fa-tasks fa-2x"></i>&nbsp;&nbsp; Demo</a></li>
										<li><a href="checkout.html"><i class="fa fa-files-o fa-2x"></i>&nbsp;&nbsp; Demo</a></li>
									 </ul> 
								</div>
							</div>
							
							<div class="side-widget">
								<h2 class="side-widget-title">LATEST ISSUES</h2>
								<div class="widget-text padd-0">
									 <ul class="footer-menu">
									    <li><a href="browse-candidate-list.html"><i class="fa fa-stack-overflow fa fa-2x"></i>&nbsp;&nbsp;  Demo 2021</a></li>
										<li><a href="browse-employer-list.html"><i class="fa fa-stack-overflow fa fa-2x"></i>&nbsp;&nbsp; Demo 2021</a></li>
										<li><a href="advance-search-2.html"><i class="fa fa-stack-overflow fa fa-2x"></i>&nbsp;&nbsp; Demo 2021</a></li>
										<li><a href="checkout.html"><i class="fa fa-stack-overflow fa fa-2x"></i>&nbsp;&nbsp; Demo 2021</a></li>
										<li><a href="checkout.html"><i class="fa fa-stack-overflow fa fa-2x"></i>&nbsp;&nbsp; Demo 2021</a></li>
										<li><a href="checkout.html"><i class="fa fa-stack-overflow fa fa-2x"></i>&nbsp;&nbsp; Demo 2021</a></li>
										<li><a href="checkout.html"><i class="fa fa-stack-overflow fa fa-2x"></i>&nbsp;&nbsp; Demo 2021</a></li>
									 </ul> 
								</div>
							</div>
							
							<div class="side-widget">
								<h2 class="side-widget-title">Recent Category</h2>
								<div class="widget-text padd-0">
									
									<div class="blog-item">
										
									</div>
									<div class="blog-item">
										
										<div class="blog-detail">
											<a href="blog-details.html"><h4>Enim Ad Minim Veniam, Quis Nostrud Exercitation</h4></a>
											<div class="post-info">Aug 10 2021</div>
										</div>
									</div>
									
									<div class="blog-item">
										
										<div class="blog-detail">
											<a href="blog-details.html"><h4>Enim Ad Minim Veniam, Quis Nostrud Exercitation</h4></a>
											<div class="post-info">Aug 10 2021</div>
										</div>
									</div>
									<div class="blog-item">
										
										<div class="blog-detail">
											<a href="blog-details.html"><h4>Enim Ad Minim Veniam, Quis Nostrud Exercitation</h4></a>
											<div class="post-info">Aug 10 2021</div>
										</div>
									</div>
								</div>
							</div>
							
							
							
						
							
						</div>
					</div>
					<!-- Sidebar End -->
					
				</div>
			</section>
			<!-- ========== Begin: Brows job Category End ===============  -->
			<?php   include("view/common/footer.php")?>